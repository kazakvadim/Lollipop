package com.example.kazak.lollipop

import android.app.Activity
import android.content.Context
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.hardware.usb.UsbDevice.getDeviceId
import android.content.Context.TELEPHONY_SERVICE
import android.content.pm.ActivityInfo
import android.content.pm.PackageManager
import android.os.PersistableBundle
import android.support.v4.app.ActivityCompat
import android.support.v4.content.ContextCompat
import android.support.v4.content.ContextCompat.getSystemService
import android.telephony.TelephonyManager
import android.view.View
import android.widget.TextView
import android.widget.Toast
import java.util.jar.Manifest
import kotlinx.android.synthetic.main.activity_main.*

import android.util.Log;

class MainActivity : AppCompatActivity() {
    val IMEI_PERMISSION_CODE = 1
    private val TAG = "MainActivity"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        versionView.text = BuildConfig.VERSION_NAME
        if (savedInstanceState != null && savedInstanceState.containsKey("savedIMEI")){
            IMEIView.text = savedInstanceState.getString("savedIMEI")
        }
        else{
            if (ActivityCompat.checkSelfPermission(this,
                            android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
                getIMEI()
            } else {
                requestImeiPermission();
            }
        }

     }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "onPause");
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "onResume");
    }

    override fun onRestart() {
        super.onRestart()
        Log.d(TAG, "onRestart");
    }

    override fun onStart() {
        super.onStart()
        Log.d(TAG, "onStart");
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "onStop");
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy");
    }

    override fun onRestoreInstanceState(savedInstanceState: Bundle?) {
        super.onRestoreInstanceState(savedInstanceState)
        Log.d(TAG, "onRestoreInstanceState");
    }



    override fun onSaveInstanceState(outState: Bundle?, outPersistentState: PersistableBundle?) {
        outState?.putString("savedIMEI", IMEIView.text.toString())
        super.onSaveInstanceState(outState, outPersistentState)
    }

//    override fun onRestoreInstanceState(savedInstanceState: Bundle?) {
//        super.onRestoreInstanceState(savedInstanceState)
//        IMEIView.text = savedInstanceState?.getString("savedIMEI")
//    }

    fun getIMEI(){
        val telephonyManager = getSystemService(Context.TELEPHONY_SERVICE) as TelephonyManager
        val imei = telephonyManager.deviceId
        IMEIView.text = imei
    }

    fun request_button(view: View){
        if (ActivityCompat.checkSelfPermission(this,
                        android.Manifest.permission.READ_PHONE_STATE) == PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, getString(R.string.permission_granted_text),
                    Toast.LENGTH_SHORT).show()
        } else {
            requestImeiPermission();
        }
    }

    fun requestImeiPermission(){
        if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                        android.Manifest.permission.READ_PHONE_STATE)){
            Toast.makeText(this, getString(R.string.need_permission),
                    Toast.LENGTH_LONG).show()
        }
            ActivityCompat.requestPermissions(this,
                    arrayOf(android.Manifest.permission.READ_PHONE_STATE), IMEI_PERMISSION_CODE)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        if (requestCode == IMEI_PERMISSION_CODE){
            if (grantResults.size > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                Toast.makeText(this, getString(R.string.permission_granted_text_short), Toast.LENGTH_SHORT).show()
                getIMEI()
            } else {
                Toast.makeText(this, getString(R.string.permission_denied_text_short), Toast.LENGTH_SHORT).show()
            }
        }
    }
}
